from django.apps import AppConfig


class VicksappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'vicksapp'
